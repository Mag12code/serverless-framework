"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamodb_1 = require("../utils/dynamodb");
const handler = async (event) => {
    var _a;
    try {
        if (!((_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id)) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Missing id parameter' }),
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                },
            };
        }
        await (0, dynamodb_1.deleteItem)(event.pathParameters.id);
        const response = {
            statusCode: 204,
            body: '',
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
        };
        return response;
    }
    catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=delete.js.map