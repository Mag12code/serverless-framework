"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
const dynamodb_1 = require("../utils/dynamodb");
const handler = async (event) => {
    var _a;
    try {
        if (!((_a = event.pathParameters) === null || _a === void 0 ? void 0 : _a.id)) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Missing id parameter' }),
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                },
            };
        }
        if (!event.body) {
            return {
                statusCode: 400,
                body: JSON.stringify({ error: 'Missing request body' }),
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                },
            };
        }
        const updates = JSON.parse(event.body);
        const result = await (0, dynamodb_1.updateItem)(event.pathParameters.id, updates);
        if (!result) {
            return {
                statusCode: 404,
                body: JSON.stringify({ error: 'Item not found' }),
                headers: {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*',
                },
            };
        }
        const response = {
            statusCode: 200,
            body: JSON.stringify(result),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
        };
        return response;
    }
    catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: 'Internal server error' }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
            },
        };
    }
};
exports.handler = handler;
//# sourceMappingURL=update.js.map